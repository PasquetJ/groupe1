import java.util.ArrayList;
import java.util.Arrays;

public class TestReponse 
{

	public static void main(String[] args)
	{
		ArrayList<Integer> listeRecherche = new ArrayList(Arrays.asList(new Integer[]{8,2,3,2})) ;
		ArrayList<Integer> listeDeviner = new ArrayList(Arrays.asList(new Integer[]{2,3,2,0})) ;
		
		int[] listeTrouve = new int[2];
		
		
		for (int i = 0 ; i < listeRecherche.size() ; i++)
		{
			System.out.print(listeRecherche.get(i)+ " ");
		}
		System.out.println("");
		for (int i = 0 ; i < listeRecherche.size() ; i++)
		{
			System.out.print(listeDeviner.get(i)+ " ");
		}
		System.out.println("");

		listeTrouve = Reponse.Trouve(listeRecherche, listeDeviner);
		

		
		
		System.out.println("\nVous avez " + listeTrouve[0] + " bonnes réponses à la bonne place \nVous avez " + listeTrouve[1] +" bonne réponses à la mauvaise place" );
		
	}

	
}
